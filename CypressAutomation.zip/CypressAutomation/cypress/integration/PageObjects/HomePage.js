class HomePage{

    getEditBox(){
        return cy.get("input[name='name']:nth-child(2)");
    }

    getGender(){
       return cy.get("select");
    }

    getTwoWayBinding(){
        return cy.get("input[name='name']:nth-child(1)");
    }

    checkifElementDisabled(){
        return cy.get("#inlineRadio3");
    }

    getShopButton(){
        return cy.get("li:nth-child(2) > a");
    }
    
}

export default HomePage;