class PurchasePage{

    retriveLocation(){
        return cy.get("#country");
    }

    selectLocation(){
        return cy.get("div.suggestions ul li:nth-child(1)");
    }

    purchaseClick(){
        return  cy.get("input[type='submit']");
    }

    getTermsAndCond(){
        return cy.get("label[for='checkbox2']");
    }

    getAlertMsg(){
        return cy.get(".alert");
    }

   


    
}

export default PurchasePage;