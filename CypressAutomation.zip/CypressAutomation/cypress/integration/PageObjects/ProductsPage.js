class ProductsPage{

    clickCheckOut(){
        return cy.get("li.nav-item.active");
    }
    
}

export default ProductsPage;