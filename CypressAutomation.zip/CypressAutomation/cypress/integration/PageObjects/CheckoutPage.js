class CheckoutPage{

    clickCheckOutFinal(){
        return cy.get("button.btn.btn-success");
    }
    
}

export default CheckoutPage;