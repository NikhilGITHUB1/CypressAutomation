//cypress
/// <reference types="Cypress" />

describe('My first test suite',function(){
  
    it('my first test case',function(){
        cy.visit("https://rahulshettyacademy.com/seleniumPractise/#/")
        cy.get(".search-keyword").type("ca")
        cy.wait(1000)
        //adding assertions 
        cy.get("div.product:visible").should("have.length",4) // added jquery to fix the issue
        // parent child chaining
        //aliasing
        cy.get(".products").as("productlist")

        cy.get("@productlist").find(".product").should("have.length",4)
        // to select a product and click
        cy.get("@productlist").find(".product").should("have.length",4).eq(2).contains("ADD TO CART").click().then(function()
        {
            console.log("nikhil") // here we manually resolved the promise
        }

        )


        //console.log("nikhil") // here it is asynchronous

        //avoiding index and using each method 
        cy.get(".products").find(".product").each(($el, index, $list) => {

            const textVeg=$el.find("h4.product-name").text()
            if(textVeg.includes("Cashews")){
                cy.wrap($el).find("button").click();

            }
            
        })

        //using assertions in text
        cy.get(".brand").should("have.text","GREENKART")


        //print in log
        cy.get(".brand").then(function(logoElement) // handling promise if you want to use variables 
         {
            cy.log(logoElement.text()) // it is synchronous 
        
         }
    
        )
            
        }

    )

}
)

