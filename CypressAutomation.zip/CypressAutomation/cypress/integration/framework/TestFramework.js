//cypress
/// <reference types="Cypress" />
import HomePage from "../PageObjects/HomePage"
import ProductsPage from "../PageObjects/ProductsPage"
import CheckoutPage from "../PageObjects/CheckoutPage"
import PurchasePage from "../PageObjects/PurchasePage"



describe('My first test suite',function(){
const homepage = new HomePage();
const productpage = new ProductsPage();
const checkoutpage = new CheckoutPage();
const purchasepage = new PurchasePage();



    before(function(){
        //runs tests before all tests
        cy.fixture("example").then(function(data) {
            this.data=data;
        });
    })
  
    it('my first test case',function(){
     
        cy.visit(Cypress.env('url')+"/angularpractice");
        homepage.getEditBox().type(this.data.name);
        homepage.getGender().select(this.data.gender);  
        //1st way to validate the value
        homepage.getTwoWayBinding().should("have.value",this.data.name);
        //2nd way to fetch the value in log
        cy.get("input[name='name']:nth-child(1)").then(function(test) {

            const test1=test.val();
            cy.log(test1);
            
        });

        //1st way to fetch attribute value
        homepage.getEditBox().should("have.attr","minlength","2");
         
        //2nd way to fetch attribute value
        // cy.get("input[name='name']:nth-child(2)").then(function(el)
        // {
        //     const el1=el.prop('minlength');
        //     cy.log(el1);
        // });

        homepage.checkifElementDisabled().should("be.disabled");

        //Build customized Cypress commands
        homepage.getShopButton().click();
        
        // cy.selectProduct("Samsung");
        // cy.selectProduct("Blackberry");

        this.data.productName.forEach((element) => {

            cy.selectProduct(element);
        });

        productpage.clickCheckOut().click();
        var sum=0;
        //var total=0;
    

        //Logic to sum the mobile prices:
        cy.get("tr td:nth-child(4) strong").each(($el, index, $list) => {

            const text=$el.text();
            var res = text.split(" ");
            res = res[1].trim();
            sum=Number(sum)+Number(res);
        
        }).then(function()
        {
            cy.log(sum);
        }

        );

        //get total, fetch string
        cy.get("td h3 strong").then(function(element){
            const text = element.text();
            var res = text.split(" ");
            res = res[1].trim();
            var total = Number(res);
            cy.log(total);

        //compare number
        expect(total).to.equal(sum);

        });

      

        checkoutpage.clickCheckOutFinal().click();

        purchasepage.retriveLocation().type("India");
        purchasepage.selectLocation().click();
        purchasepage.getTermsAndCond().click({force: true});
        purchasepage.purchaseClick().click();
       // cy.get('.alert').should("have.text","Success! Thank you! Your order will be delivered in next few weeks :-)");
     
    
       // Cypress.config("defaultCommandTimeout",8000)
       purchasepage.getAlertMsg().then(function(element){
        const text = element.text();
        expect(text.includes("Success")).to.be.true;
       })

    })
})
