import { Given, When, Then } from "@badeball/cypress-cucumber-preprocessor";
/// <reference types="Cypress" />


import HomePage from "../../../PageObjects/HomePage"
import ProductsPage from "../../../PageObjects/ProductsPage"
import CheckoutPage from "../../../PageObjects/CheckoutPage"
import PurchasePage from "../../../PageObjects/PurchasePage"
let name;
const homepage = new HomePage(); 
const productpage = new ProductsPage();
const checkoutpage = new CheckoutPage();
const purchasepage = new PurchasePage();

Given("I open Ecommerce page", ()=>{
    cy.visit(Cypress.env('url')+"/angularpractice");
});


When("I add items to Cart", function(){

    homepage.getShopButton().click();
    this.data.productName.forEach((element) => {

        cy.selectProduct(element);
    });

    productpage.clickCheckOut().click();

});


When("validate the total price", ()=>{

    var sum=0;
    cy.get("tr td:nth-child(4) strong").each(($el, index, $list) => {

        const text=$el.text();
        var res = text.split(" ");
        res = res[1].trim();
        sum=Number(sum)+Number(res);
    
    }).then(function()
    {
        cy.log(sum);
    }

    );

    //get total, fetch string
    cy.get("td h3 strong").then(function(element){
        const text = element.text();
        var res = text.split(" ");
        res = res[1].trim();
        var total = Number(res);
        cy.log(total);

    //compare number
    expect(total).to.equal(sum);

    });
});

Then("select the country submit and verify Success message", ()=>{

    checkoutpage.clickCheckOutFinal().click();

    purchasepage.retriveLocation().type("India");
    purchasepage.selectLocation().click();
    purchasepage.getTermsAndCond().click({force: true});
    purchasepage.purchaseClick().click();
   // cy.get('.alert').should("have.text","Success! Thank you! Your order will be delivered in next few weeks :-)");
 

   // Cypress.config("defaultCommandTimeout",8000)
   purchasepage.getAlertMsg().then(function(element){
    const text = element.text();
    expect(text.includes("Success")).to.be.true;

   })
});


//When I enter details
When("I enter details and validate", function(dataTable){
        name = dataTable.rawTable[1][0];
        homepage.getEditBox().type(dataTable.rawTable[1][0]);
        homepage.getGender().select(dataTable.rawTable[1][1]);  
        //1st way to validate the value
        homepage.getTwoWayBinding().should("have.value",name);

        //1st way to fetch attribute value
        homepage.getEditBox().should("have.attr","minlength","2");
        homepage.checkifElementDisabled().should("be.disabled");


});

//Then I click on shop button
Then("I click on shop button", function(){
      
       homepage.getShopButton().click();
});








