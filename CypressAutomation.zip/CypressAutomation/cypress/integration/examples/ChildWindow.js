//table[name='courses'] tr td:nth-child(2)

//cypress
/// <reference types="Cypress" />

describe('My first test suite',function(){
  
    it('my first test case',function(){
        cy.visit("https://rahulshettyacademy.com/AutomationPractice/#/");
        cy.get("#opentab").then(function(url) {
            const url1 = url.prop("href");
            cy.log(url1);
            cy.get("#opentab").invoke("removeAttr","target").click();
            
        })

       

    })
})
