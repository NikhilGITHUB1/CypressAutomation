//cypress
/// <reference types="Cypress" />

describe('My first test suite',function(){
  
    it('my first test case',function(){
        cy.visit("https://rahulshettyacademy.com/AutomationPractice/#/");
        cy.get("#checkBoxOption1").check().should("be.checked").and("have.value","option1");
        cy.wait(1000);
        cy.get("#checkBoxOption1").uncheck().should("not.be.checked");
        cy.get("input[type='checkbox']").check(["option1","option2"])

        //visible
        cy.get("#displayed-text").should("be.visible");
        cy.get("#hide-textbox").click();
        cy.get("#displayed-text").should("not.be.visible");
        cy.get("#show-textbox").click();
        cy.get("#displayed-text").should("be.visible");






    }
    )
}
)