//table[name='courses'] tr td:nth-child(2)

//cypress
/// <reference types="Cypress" />

describe('My first test suite',function(){
  
    it('my first test case',function(){
        cy.visit("https://rahulshettyacademy.com/AutomationPractice/#/");

        cy.get("table[name='courses'] tr td:nth-child(2)").each(($el, index, $list) => {

            const text=$el.text();
            if(text.includes("Python")){
                cy.get("table[name='courses'] tr td:nth-child(2)").eq(index).next().then(function(price) {
                    const pricetext = price.text();
                    expect(pricetext).to.equal("25");
                    
                })

            }
            
        })
     
        
    })
})
