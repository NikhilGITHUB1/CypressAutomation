//cypress
/// <reference types="Cypress" />

describe('My first test suite',function(){
  
    it('my first test case',function(){
        cy.visit("https://rahulshettyacademy.com/AutomationPractice/#/");
        cy.get("#opentab").invoke("removeAttr","target").click();

        //assertion before browser control
        cy.url().should("include","https://www.rahulshettyacademy.com/");

        //Browser control
        cy.go("back");
        
    })
})
